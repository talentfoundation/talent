#!/usr/bin/env bash

export LC_ALL=C
TOPDIR=${TOPDIR:-$(git rev-parse --show-toplevel)}
BUILDDIR=${BUILDDIR:-$TOPDIR}

BINDIR=${BINDIR:-$BUILDDIR/src}
MANDIR=${MANDIR:-$TOPDIR/doc/man}

TALENTD=${TALENTD:-$BINDIR/talentd}
TALENTCLI=${TALENTCLI:-$BINDIR/talent-cli}
TALENTTX=${TALENTTX:-$BINDIR/talent-tx}
TALENTQT=${TALENTQT:-$BINDIR/qt/talent-qt}

[ ! -x $TALENTD ] && echo "$TALENTD not found or not executable." && exit 1

# The autodetected version git tag can screw up manpage output a little bit
TLTVER=($($TALENTCLI --version | head -n1 | awk -F'[ -]' '{ print $6, $7 }'))

# Create a footer file with copyright content.
# This gets autodetected fine for talentd if --version-string is not set,
# but has different outcomes for talent-qt and talent-cli.
echo "[COPYRIGHT]" > footer.h2m
$TALENTD --version | sed -n '1!p' >> footer.h2m

for cmd in $TALENTD $TALENTCLI $TALENTTX $TALENTQT; do
  cmdname="${cmd##*/}"
  help2man -N --version-string=${TLTVER[0]} --include=footer.h2m -o ${MANDIR}/${cmdname}.1 ${cmd}
  sed -i "s/\\\-${TLTVER[1]}//g" ${MANDIR}/${cmdname}.1
done

rm -f footer.h2m
