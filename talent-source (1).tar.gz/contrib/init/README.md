Sample configuration files for:
```
SystemD: talentd.service
Upstart: talentd.conf
OpenRC:  talentd.openrc
         talentd.openrcconf
CentOS:  talentd.init
macOS:    org.talent.talentd.plist
```
have been made available to assist packagers in creating node packages here.

See doc/init.md for more information.
